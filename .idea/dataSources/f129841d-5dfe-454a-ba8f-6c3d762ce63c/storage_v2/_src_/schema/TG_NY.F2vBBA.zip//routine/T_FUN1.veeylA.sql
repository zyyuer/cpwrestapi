create function t_fun1
return number
is 

   info    VARCHAR2(40);
  
BEGIN
  info := '&info';
  DBMS_OUTPUT.PUT_LINE(info);
  return 1;
END;
/

