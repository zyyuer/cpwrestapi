create FUNCTION           FN_SPLIT_HIS_YZH(v_Instr In Varchar2)
	Return Varchar2 Is
	v_his_dradno   Varchar2(32);
	v_Pos1  Integer;
	v_Pos2  Integer;
Begin

If v_Instr Is Null Or Length(Ltrim(v_Instr)) = 0 Then
	v_his_dradno := '';
Else
	
	v_Pos1 := instr( v_Instr, '_', 1, 1 );
	v_Pos2 := instr( v_Instr, '_', 1, 2 );
	
	if v_Pos1 > 0 and v_Pos2 > 0 then
		v_his_dradno := substr(v_Instr, 1, v_Pos2 - 1);
	Else
		v_his_dradno := v_Instr;
	End if;
End if;
Return(v_his_dradno);

End;
/

