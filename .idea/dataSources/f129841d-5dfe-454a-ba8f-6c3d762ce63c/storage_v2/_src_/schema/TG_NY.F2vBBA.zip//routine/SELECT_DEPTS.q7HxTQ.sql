create procedure select_depts(ref_cur1 out sys_refcursor,
                                         ref_cur2 out sys_refcursor) is
begin
  open ref_cur1 for
    select dept_code, dept_name
      from code_department
     where dept_code like '01%';
  open ref_cur2 for
    select dept_code, dept_name
      from code_department
     where dept_code like '02%';
end select_depts;
/

