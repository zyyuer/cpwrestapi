create function FN_MD5_INFC_CP(input_string VARCHAR2) return varchar2 IS
  raw_input     RAW(4000) := UTL_RAW.CAST_TO_RAW(input_string);
  decrypted_raw RAW(2048);
  error_in_input_buffer_length EXCEPTION;
BEGIN
  sys.dbms_obfuscation_toolkit.MD5(input    => raw_input,
                                   checksum => decrypted_raw);
  return substr(lower(rawtohex(decrypted_raw)), 7,20);

END;
/

