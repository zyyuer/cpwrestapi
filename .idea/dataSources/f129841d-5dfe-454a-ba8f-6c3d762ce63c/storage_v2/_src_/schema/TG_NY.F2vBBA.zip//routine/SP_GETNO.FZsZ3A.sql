create PROCEDURE sp_getno 
  @NO INT OUTPUT;
AS
BEGIN
  SELECT @NO = count(drgs_code) FROM code_drgs

  IF @NO <> 0
    BEGIN
      SET @NO = @NO      
    END
    ELSE
    BEGIN
      SET @NO = 1      
    END

END
  /

