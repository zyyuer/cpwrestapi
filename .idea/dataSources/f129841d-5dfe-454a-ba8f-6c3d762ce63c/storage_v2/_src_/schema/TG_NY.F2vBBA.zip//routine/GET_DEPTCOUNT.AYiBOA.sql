create procedure get_deptcount(v_id in char,v_deptcount out number)
as
begin
  v_deptcount := 0;
select count(dept_code) into v_deptcount from code_department where dept_code like v_id; 
exception
when no_data_found then
raise_application_error(-20001,'ID不存在!');
end get_deptcount;
/

